export default function TestTailwind() {
  return (
    <div className="bg-red-500 text-white p-4 rounded-lg shadow-lg">
      If you see a red box with shadow, Tailwind is working!
    </div>
  );
}
